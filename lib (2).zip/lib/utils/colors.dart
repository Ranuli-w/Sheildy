
import 'package:flutter/material.dart';

const mobileBackgroundColor = Color.fromRGBO(0, 0, 0, 1);
const webBackgroundColor = Color.fromRGBO(18, 18, 18, 1);
const blueColor = Color.fromRGBO(1, 145, 241, 1);
const primaryColor = Colors.white;
const secondaryColor = Color.fromARGB(228, 158, 158, 158);
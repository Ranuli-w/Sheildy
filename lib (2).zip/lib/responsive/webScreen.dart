import 'package:flutter/material.dart';

class webScreenLayout extends StatelessWidget {
  const webScreenLayout({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body:Center(
          child: Text('web Screen'),
        ),
      
    );
  }
}